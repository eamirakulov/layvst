<div class="qodef-ps-info-item qodef-ps-content-title">
    <h2 class="qodef-ps-info-main-title"><?php the_title(); ?></h2>
</div>