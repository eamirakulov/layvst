<div class="qodef-vss-ms-section" <?php echo succulents_qodef_get_inline_attrs($content_data); ?> <?php succulents_qodef_inline_style($content_style);?>>
	<?php echo do_shortcode($content); ?>
</div>