<?php

include_once QODE_CORE_SHORTCODES_PATH . '/tabs/functions.php';
include_once QODE_CORE_SHORTCODES_PATH . '/tabs/tabs.php';
include_once QODE_CORE_SHORTCODES_PATH . '/tabs/tabs-item.php';